import numpy as np, torch, pandas as pd
from datasets import load_from_disk
from transformers import AutoTokenizer, AutoModelForSequenceClassification, DataCollatorWithPadding
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix

DATA_DIR="imdb_tokenized_256"; MODEL="roberta-base"
dset=load_from_disk(DATA_DIR)
tok=AutoTokenizer.from_pretrained(MODEL, use_fast=True)
collate=DataCollatorWithPadding(tokenizer=tok)
val_loader=DataLoader(dset["validation"], batch_size=128, shuffle=False, collate_fn=collate)

device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
model=AutoModelForSequenceClassification.from_pretrained(MODEL, num_labels=2).to(device).eval()

# If you want to evaluate the exact ES-trained weights currently in memory, skip reloading the model above
# and just import lin from your training script. Otherwise this evaluates a fresh model (baseline).
# Better: save from ES run and load; or re-run ES with saving enabled.

preds=[]; labels=[]
with torch.no_grad():
    for b in val_loader:
        out=model(input_ids=b["input_ids"].to(device), attention_mask=b["attention_mask"].to(device))
        preds.append(out.logits.argmax(-1).cpu().numpy())
        labels.append(b["labels"].numpy())
preds=np.concatenate(preds); labels=np.concatenate(labels)

acc=float(accuracy_score(labels,preds)); f1=float(f1_score(labels,preds,average="macro"))
print(f"Val Accuracy: {acc:.4f} | Macro-F1: {f1:.4f}")
print(classification_report(labels,preds,digits=4))
cm=confusion_matrix(labels,preds); print(cm)
pd.DataFrame({"label":labels,"pred":preds}).to_csv("es_val_predictions.csv",index=False)
with open("es_report.txt","w") as f:
    f.write(f"Val Accuracy: {acc:.6f}\nMacro-F1: {f1:.6f}\n")

