import random, numpy as np, torch
from torch.utils.data import DataLoader
from datasets import load_from_disk
from transformers import AutoTokenizer, AutoModelForSequenceClassification, DataCollatorWithPadding

# ----------------- Config (FAST DEMO) -----------------
SUBSET_N = None   # or 0, to use ALL data
POP = 64          # you can raise this if you want
ITERS = 200       # raise if you want more search
EVAL_STEPS_PER_CAND = 8
BATCH_TRAIN = 64
BATCH_VAL = 128

# ------------------------------------------------------
SEED = 42
DATA_DIR = "imdb_tokenized_256"
MODEL_NAME = "roberta-base"

# ES hyperparameters
POP = 64          # population size
SIGMA = 0.02      # mutation noise scale
ITERS = 200       # iterations
LR = 0.01         # learning rate for ES
BATCH_TRAIN = 64  # training batch size
BATCH_VAL = 128   # validation batch size
# ===============
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Data
dset = load_from_disk(DATA_DIR)
# Use small subset for speed
if SUBSET_N:
    dset = dset.shuffle(seed=SEED)
    dset["train"] = dset["train"].select(range(min(SUBSET_N, len(dset["train"]))))
    dset["validation"] = dset["validation"].select(range(min(SUBSET_N, len(dset["validation"]))))

tok = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=True)
collate = DataCollatorWithPadding(tokenizer=tok)
train_loader = DataLoader(dset["train"], batch_size=BATCH_TRAIN, shuffle=True, collate_fn=collate)
val_loader   = DataLoader(dset["validation"], batch_size=BATCH_VAL, shuffle=False, collate_fn=collate)

# Model
model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME, num_labels=2).to(device)
model.eval()

# Freeze backbone
if hasattr(model, "roberta"):
    for p in model.roberta.parameters():
        p.requires_grad = False
elif hasattr(model, "base_model"):
    for p in model.base_model.parameters():
        p.requires_grad = False

# Get classifier head
head = model.classifier
lin = getattr(head, "out_proj", head)

def pack_head():
    with torch.no_grad():
        return torch.cat([lin.weight.detach().cpu().flatten(),
                          lin.bias.detach().cpu().flatten()])

def unpack_head(theta):
    with torch.no_grad():
        wnum = lin.weight.numel()
        lin.weight.copy_(theta[:wnum].view_as(lin.weight))
        lin.bias.copy_(theta[wnum:].view_as(lin.bias))

theta = pack_head()
DIM = theta.numel()
print(f"ES head-only | dim={DIM}, pop={POP}, sigma={SIGMA}, iters={ITERS}")

@torch.no_grad()
def batch_loss(batch):
    out = model(
        input_ids=batch["input_ids"].to(device),
        attention_mask=batch["attention_mask"].to(device),
        labels=batch["labels"].to(device),
    )
    return float(out.loss)

@torch.no_grad()
def evaluate_subset(loader, steps=20):
    total, n = 0.0, 0
    it = iter(loader)
    for _ in range(steps):
        try:
            batch = next(it)
        except StopIteration:
            it = iter(loader)
            batch = next(it)
        total += batch_loss(batch)
        n += 1
    return total / max(n, 1)

@torch.no_grad()
def val_accuracy():
    correct, total = 0, 0
    for batch in val_loader:
        out = model(
            input_ids=batch["input_ids"].to(device),
            attention_mask=batch["attention_mask"].to(device),
        )
        preds = out.logits.argmax(-1).cpu()
        y = batch["labels"]
        correct += (preds == y).sum().item()
        total += y.shape[0]
    return correct / total

best_theta = theta.clone()
best_acc = 0.0

for t in range(1, ITERS + 1):
    noises = torch.randn(POP // 2, DIM)
    rewards = []
    train_it = iter(train_loader)

    for eps in noises:
        for sign in (+1, -1):
            cand = theta + sign * SIGMA * eps
            unpack_head(cand)
            tot = 0.0
            for _ in range(EVAL_STEPS_PER_CAND):
                try:
                    batch = next(train_it)
                except StopIteration:
                    train_it = iter(train_loader)
                    batch = next(train_it)


import torch
torch.save(
    {"weight": lin.weight.detach().cpu(), "bias": lin.bias.detach().cpu()},
    "es_head_best.pt"
)
print("Saved ES head to es_head_best.pt")
