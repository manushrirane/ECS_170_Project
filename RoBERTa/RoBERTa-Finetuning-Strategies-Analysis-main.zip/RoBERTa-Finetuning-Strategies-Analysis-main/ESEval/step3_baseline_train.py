from transformers import (
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    AutoTokenizer,
    DataCollatorWithPadding,
)
from datasets import load_from_disk
import evaluate, numpy as np

# Load tokenized data saved in Step 2 (has 'labels' column)
dataset = load_from_disk("imdb_tokenized_256")
tokenizer = AutoTokenizer.from_pretrained("roberta-base", use_fast=True)
collate = DataCollatorWithPadding(tokenizer=tokenizer)

# Model
model = AutoModelForSequenceClassification.from_pretrained("roberta-base", num_labels=2)

# Metrics
metric_acc = evaluate.load("accuracy")
metric_f1  = evaluate.load("f1")

def compute_metrics(p):
    preds = np.argmax(p.predictions, axis=1)
    return {
        "accuracy": metric_acc.compute(predictions=preds, references=p.label_ids)["accuracy"],
        "f1": metric_f1.compute(predictions=preds, references=p.label_ids, average="macro")["f1"],
    }

# Training args (compatible with older Transformers)
args = TrainingArguments(
    output_dir="roberta_imdb_baseline",
    per_device_train_batch_size=16,
    per_device_eval_batch_size=32,
    learning_rate=2e-5,
    num_train_epochs=1,     # just a yardstick
    logging_steps=100,
    fp16=False,
    report_to="none",
)

trainer = Trainer(
    model=model,
    args=args,
    train_dataset=dataset["train"],
    eval_dataset=dataset["validation"],
    tokenizer=tokenizer,
    data_collator=collate,
    compute_metrics=compute_metrics,
)

trainer.train()
print(trainer.evaluate())

