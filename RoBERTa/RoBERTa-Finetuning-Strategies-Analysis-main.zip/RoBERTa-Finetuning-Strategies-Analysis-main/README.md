# RoBERTa-Finetuning-Strategies-Analysis
ECS170 Project


`RoBERTa Evaluation/` is for evaluating the performance of pure un-fine-tuned RoBERTa on the IMDB movie dataset.
 