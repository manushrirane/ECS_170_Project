import os, random
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from datasets import Dataset, DatasetDict
from transformers import AutoTokenizer

SEED = 42
random.seed(SEED); np.random.seed(SEED)

# 1) Load CSV (adjust path if needed)
csv_path = "/Users/akshitharajendran/Documents/roberta_es_project/IMDB Dataset.csv"
df = pd.read_csv(csv_path)

# 2) Build binary label
df["label"] = (df["sentiment"].str.lower() == "positive").astype(int)
df = df[["review","label"]]

# 3) Stratified 50/50 split (IMDB is already balanced)
train_df, val_df = train_test_split(
    df, test_size=0.5, stratify=df["label"], random_state=SEED
)

# 4) Tokenizer (RoBERTa)
tokenizer = AutoTokenizer.from_pretrained("roberta-base", use_fast=True)

def tok(batch):
    return tokenizer(batch["review"], truncation=True, max_length=256)

# 5) HuggingFace Datasets + tokenize
train_ds = Dataset.from_pandas(train_df.reset_index(drop=True))
val_ds   = Dataset.from_pandas(val_df.reset_index(drop=True))

train_ds = train_ds.map(tok, batched=True, remove_columns=["review"])
val_ds   = val_ds.map(tok, batched=True, remove_columns=["review"])

# 6) Rename label column to 'labels' for HF models
train_ds = train_ds.rename_column("label", "labels")
val_ds   = val_ds.rename_column("label", "labels")

# 7) Save to disk for reuse
dset = DatasetDict({"train": train_ds, "validation": val_ds})
out_dir = "imdb_tokenized_256"
dset.save_to_disk(out_dir)

# 8) Quick sanity prints
print("Saved tokenized dataset to:", out_dir)
print("Train size:", len(dset["train"]), "Val size:", len(dset["validation"]))
print("Example input_ids length:", len(dset["train"][0]["input_ids"]))
print("Label distribution (train):",
      pd.Series([x for x in train_df['label']]).value_counts().to_dict())
print("Label distribution (val):",
      pd.Series([x for x in val_df['label']]).value_counts().to_dict())

