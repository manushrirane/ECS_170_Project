# step5_es_report.py  — fast evaluation version
import os, time, numpy as np, torch, pandas as pd
from datasets import load_from_disk
from transformers import AutoTokenizer, AutoModelForSequenceClassification, DataCollatorWithPadding
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix

# ---------- Config ----------
DATA_DIR   = "imdb_tokenized_256"
MODEL_NAME = "roberta-base"
HEAD_PATH  = "es_head_best.pt"   # saved at end of step4
EVAL_LIMIT = None                
BATCH_VAL  = 256
NUM_WORKERS = 0
# -----------------------------

# Prefer Apple MPS → CUDA → CPU
if torch.backends.mps.is_available():
    device = torch.device("mps")
elif torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")
print(f"⚙️  Using device: {device}")

# Load tokenized dataset
dset = load_from_disk(DATA_DIR)
dset = dset.shuffle(seed=42)
if EVAL_LIMIT is not None:
    dset["validation"] = dset["validation"].select(range(min(EVAL_LIMIT, len(dset["validation"]))))
    print(f"⚡ Evaluating only {len(dset['validation'])} validation samples for speed.")

# Collator / DataLoader
tok = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=True)
collate = DataCollatorWithPadding(tokenizer=tok)
val_loader = DataLoader(
    dset["validation"],
    batch_size=BATCH_VAL,
    shuffle=False,
    collate_fn=collate,
    num_workers=NUM_WORKERS,
    pin_memory=False,
)

# Load model and inject ES head
model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME, num_labels=2).to(device)
model.eval()
head = model.classifier
lin = getattr(head, "out_proj", head)

if os.path.exists(HEAD_PATH):
    ckpt = torch.load(HEAD_PATH, map_location="cpu")
    with torch.no_grad():
        lin.weight.copy_(ckpt["weight"].to(lin.weight.dtype))
        lin.bias.copy_(ckpt["bias"].to(lin.bias.dtype))
    print(f"✅ Loaded ES head from: {HEAD_PATH}")
else:
    print(f"⚠️  '{HEAD_PATH}' not found — evaluating untrained head (expect low scores).")

# Inference loop
t0 = time.time()
preds, labels = [], []
with torch.no_grad():
    for i, batch in enumerate(val_loader, 1):
        out = model(
            input_ids=batch["input_ids"].to(device),
            attention_mask=batch["attention_mask"].to(device),
        )
        preds.append(out.logits.argmax(-1).cpu().numpy())
        labels.append(batch["labels"].numpy())
        if i % 10 == 0:
            print(f"… evaluated {i * BATCH_VAL} samples")

elapsed = time.time() - t0
preds = np.concatenate(preds)
labels = np.concatenate(labels)

# Metrics
acc = float(accuracy_score(labels, preds))
f1  = float(f1_score(labels, preds, average="macro"))
report = classification_report(labels, preds, digits=4)
cm = confusion_matrix(labels, preds)

print(f"\n🎯 ES (head-only) | Val Accuracy = {acc:.4f} | Macro-F1 = {f1:.4f} | Time = {elapsed:.1f}s")
print("\nClassification report:\n", report)
print("Confusion matrix:\n", cm)

# Save outputs
pd.DataFrame({"label": labels, "pred": preds}).to_csv("es_val_predictions.csv", index=False)
with open("es_report.txt", "w") as f:
    f.write(f"Val Accuracy: {acc:.6f}\nMacro-F1: {f1:.6f}\nElapsedSec: {elapsed:.1f}\n\n")
    f.write("Classification report:\n")
    f.write(report)
    f.write("\nConfusion matrix:\n")
    f.write(np.array2string(cm))

print("\n📁 Saved: es_val_predictions.csv and es_report.txt")
